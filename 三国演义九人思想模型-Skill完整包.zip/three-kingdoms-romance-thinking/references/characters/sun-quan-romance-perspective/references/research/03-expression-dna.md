# 孙权｜表达结构

状态：研究草案；来源按小说分层，非历史人物事实。查阅日期：2026-10-02。

常从犹疑询问切换到公开断然决策；以主君身份确认任务、赋予执行权。愤怒时命令扩大：55回追赶刘备时对亲妹亦下极端命令，不能把这种表达美化为果断。可借其反复询问条件的结构，不模仿处刑威吓。

## 实际查阅来源

- [第44回](https://zh.wikisource.org/wiki/三國演義/第044回)
- [第54回](https://zh.wikisource.org/wiki/三國演義/第054回)
- [第55回](https://zh.wikisource.org/wiki/三國演義/第055回)
- [第67回](https://zh.wikisource.org/wiki/三國演義/第067回)
- [第75回](https://zh.wikisource.org/wiki/三國演義/第075回)
- [第82回](https://zh.wikisource.org/wiki/三國演義/第082回)
- [第83回](https://zh.wikisource.org/wiki/三國演義/第083回)
- [第84回](https://zh.wikisource.org/wiki/三國演義/第084回)
- [第108回](https://zh.wikisource.org/wiki/三國演義/第108回)

采用回次定位，内容为研究者概括；未声称逐字引文。现代行动建议是有界迁移，与原作人物伦理分开。

