# 孙权｜叙述者与他人评价

状态：研究草案；来源按小说分层，非历史人物事实。查阅日期：2026-10-02。

叙述者108回诗赞其使臣僚尽忠；44回周瑜及孔明的判断支持其尚未稳固的决心，不等于孙权自己全知；83回闞泽替陆逊担保，张昭等以名望反对。诸葛瑾82回把荆州责任推给吕蒙属于外交辩辞，不能据此洗掉孙权参与决策。

## 实际查阅来源

- [第44回](https://zh.wikisource.org/wiki/三國演義/第044回)
- [第54回](https://zh.wikisource.org/wiki/三國演義/第054回)
- [第55回](https://zh.wikisource.org/wiki/三國演義/第055回)
- [第67回](https://zh.wikisource.org/wiki/三國演義/第067回)
- [第75回](https://zh.wikisource.org/wiki/三國演義/第075回)
- [第82回](https://zh.wikisource.org/wiki/三國演義/第082回)
- [第83回](https://zh.wikisource.org/wiki/三國演義/第083回)
- [第84回](https://zh.wikisource.org/wiki/三國演義/第084回)
- [第108回](https://zh.wikisource.org/wiki/三國演義/第108回)

采用回次定位，内容为研究者概括；未声称逐字引文。现代行动建议是有界迁移，与原作人物伦理分开。

