# 孙权｜作品与版本

状态：研究草案；来源按小说分层，非历史人物事实。查阅日期：2026-10-02。

这是《三国演义》通行120回章回系统中的人物证据，不是孙权本人的著述。正文采用维基文库数字文本，未把网页断言为某一具体刊刻本的校勘定本。以回次、情节定位，繁简转换不改变模型。小说内的政治言辞常有欺骗性，不能照字面归为个人信条。

## 实际查阅来源

- [第44回](https://zh.wikisource.org/wiki/三國演義/第044回)
- [第54回](https://zh.wikisource.org/wiki/三國演義/第054回)
- [第55回](https://zh.wikisource.org/wiki/三國演義/第055回)
- [第67回](https://zh.wikisource.org/wiki/三國演義/第067回)
- [第75回](https://zh.wikisource.org/wiki/三國演義/第075回)
- [第82回](https://zh.wikisource.org/wiki/三國演義/第082回)
- [第83回](https://zh.wikisource.org/wiki/三國演義/第083回)
- [第84回](https://zh.wikisource.org/wiki/三國演義/第084回)
- [第108回](https://zh.wikisource.org/wiki/三國演義/第108回)

采用回次定位，内容为研究者概括；未声称逐字引文。现代行动建议是有界迁移，与原作人物伦理分开。

