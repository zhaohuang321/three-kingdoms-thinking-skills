# 孙权｜小说情节时间线

状态：研究草案；来源按小说分层，非历史人物事实。查阅日期：2026-10-02。

44回抗曹立盟；54—55回联姻设局失败；67回攻皖城与合肥；75回袭荆州；82—84回蜀伐吴，外交缓冲失效、起用陆逊；108回晚年太子废立与身后。

## 实际查阅来源

- [第44回](https://zh.wikisource.org/wiki/三國演義/第044回)
- [第54回](https://zh.wikisource.org/wiki/三國演義/第054回)
- [第55回](https://zh.wikisource.org/wiki/三國演義/第055回)
- [第67回](https://zh.wikisource.org/wiki/三國演義/第067回)
- [第75回](https://zh.wikisource.org/wiki/三國演義/第075回)
- [第82回](https://zh.wikisource.org/wiki/三國演義/第082回)
- [第83回](https://zh.wikisource.org/wiki/三國演義/第083回)
- [第84回](https://zh.wikisource.org/wiki/三國演義/第084回)
- [第108回](https://zh.wikisource.org/wiki/三國演義/第108回)

采用回次定位，内容为研究者概括；未声称逐字引文。现代行动建议是有界迁移，与原作人物伦理分开。

