# 孙权｜小说对话与言语情境

状态：研究草案；来源按小说分层，非历史人物事实。查阅日期：2026-10-02。

44回向周瑜追问战降条件，听到兵数及组成后解除疑虑；83回先恐惧、求和，继听闞泽举荐而排除资历反对，公开授权陆逊；82回接受魏封爵时用因时制宜解释，但魏不援吴。54—55回联姻说辞与实际囚困企图相反，应区分公开承诺与私下意图。

## 实际查阅来源

- [第44回](https://zh.wikisource.org/wiki/三國演義/第044回)
- [第54回](https://zh.wikisource.org/wiki/三國演義/第054回)
- [第55回](https://zh.wikisource.org/wiki/三國演義/第055回)
- [第67回](https://zh.wikisource.org/wiki/三國演義/第067回)
- [第75回](https://zh.wikisource.org/wiki/三國演義/第075回)
- [第82回](https://zh.wikisource.org/wiki/三國演義/第082回)
- [第83回](https://zh.wikisource.org/wiki/三國演義/第083回)
- [第84回](https://zh.wikisource.org/wiki/三國演義/第084回)
- [第108回](https://zh.wikisource.org/wiki/三國演義/第108回)

采用回次定位，内容为研究者概括；未声称逐字引文。现代行动建议是有界迁移，与原作人物伦理分开。

