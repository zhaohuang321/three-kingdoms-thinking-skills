# 庞统｜叙事阶段

连环献策（47）→孙权拒用与耒阳显才（57）→入蜀主张快速夺权（60）→三策与中计（62）→忽略进兵风险、白马误认、落凤坡被杀（63）。不同情节共同显示其灵活才智、机会意识与功名风险。

## 实际查阅来源（2026-10-02）
- 第47回：[原文](https://zh.wikisource.org/wiki/三國演義/第047回)
- 第57回：[原文](https://zh.wikisource.org/wiki/三國演義/第057回)
- 第60回：[原文](https://zh.wikisource.org/wiki/三國演義/第060回)
- 第62回：[原文](https://zh.wikisource.org/wiki/三國演義/第062回)
- 第63回：[原文](https://zh.wikisource.org/wiki/三國演義/第063回)
