# 周瑜｜小说对话与言语情境

状态：研究草案；来源按小说分层，非历史人物事实。查阅日期：2026-10-02。

44回以问各组意见探明阵营，并向孙权详陈曹军条件；45回与蔣幹的宴饮话语为设计的一部分，不能当坦诚自述；46回安排箭额及期限为害孔明；57回临终荐鲁肃属小说内遗书，较能体现任务连续性。

## 实际查阅来源

- [第44回](https://zh.wikisource.org/wiki/三國演義/第044回)
- [第45回](https://zh.wikisource.org/wiki/三國演義/第045回)
- [第46回](https://zh.wikisource.org/wiki/三國演義/第046回)
- [第47回](https://zh.wikisource.org/wiki/三國演義/第047回)
- [第54回](https://zh.wikisource.org/wiki/三國演義/第054回)
- [第55回](https://zh.wikisource.org/wiki/三國演義/第055回)
- [第57回](https://zh.wikisource.org/wiki/三國演義/第057回)

采用回次定位，内容为研究者概括；未声称逐字引文。现代行动建议是有界迁移，与原作人物伦理分开。

