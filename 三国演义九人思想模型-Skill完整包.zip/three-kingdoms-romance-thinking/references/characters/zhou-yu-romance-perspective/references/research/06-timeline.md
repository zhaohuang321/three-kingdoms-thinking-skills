# 周瑜｜小说情节时间线

状态：研究草案；来源按小说分层，非历史人物事实。查阅日期：2026-10-02。

44—47回赤壁前的条件判断、统兵、信息局及联军内冲突；54—55回荆州争夺与婚姻计失手；57回西川企图挫折、去世与荐鲁肃。

## 实际查阅来源

- [第44回](https://zh.wikisource.org/wiki/三國演義/第044回)
- [第45回](https://zh.wikisource.org/wiki/三國演義/第045回)
- [第46回](https://zh.wikisource.org/wiki/三國演義/第046回)
- [第47回](https://zh.wikisource.org/wiki/三國演義/第047回)
- [第54回](https://zh.wikisource.org/wiki/三國演義/第054回)
- [第55回](https://zh.wikisource.org/wiki/三國演義/第055回)
- [第57回](https://zh.wikisource.org/wiki/三國演義/第057回)

采用回次定位，内容为研究者概括；未声称逐字引文。现代行动建议是有界迁移，与原作人物伦理分开。

