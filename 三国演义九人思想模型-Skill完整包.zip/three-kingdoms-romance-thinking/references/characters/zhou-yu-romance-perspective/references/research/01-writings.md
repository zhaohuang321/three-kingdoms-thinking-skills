# 周瑜｜作品与版本

状态：研究草案；来源按小说分层，非历史人物事实。查阅日期：2026-10-02。

作品证据是《三国演义》章回叙述、人物对话、小说内书信，不是历史周瑜的独立著述。通行120回回次体系，数字文本不能当作校勘定本。草船借箭、群英会、三气等按小说处理，不能套到《三国志》人物。

## 实际查阅来源

- [第44回](https://zh.wikisource.org/wiki/三國演義/第044回)
- [第45回](https://zh.wikisource.org/wiki/三國演義/第045回)
- [第46回](https://zh.wikisource.org/wiki/三國演義/第046回)
- [第47回](https://zh.wikisource.org/wiki/三國演義/第047回)
- [第54回](https://zh.wikisource.org/wiki/三國演義/第054回)
- [第55回](https://zh.wikisource.org/wiki/三國演義/第055回)
- [第57回](https://zh.wikisource.org/wiki/三國演義/第057回)

采用回次定位，内容为研究者概括；未声称逐字引文。现代行动建议是有界迁移，与原作人物伦理分开。

