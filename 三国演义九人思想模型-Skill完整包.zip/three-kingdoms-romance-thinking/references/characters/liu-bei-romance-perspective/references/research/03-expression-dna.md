# 刘备｜表达方式观察

常以汉室、苍生、同宗、兄弟等关系与价值说明行动；先承认自身不足，再请求有能力者补足。姿态包括礼贤、等待、认错、恸哭。不能把哭泣一概解释为操纵术：小说提供情感表达和他人反应，不足以证明每次背后都有冷算计。现代可转化为明确使命、承认能力边界与尊重专业。

表达观察与现代建议都须标明解释层。

## 实际查阅来源（2026-10-02）
- 第37回：[原文](https://zh.wikisource.org/wiki/三國演義/第037回)
- 第38回：[原文](https://zh.wikisource.org/wiki/三國演義/第038回)
- 第41回：[原文](https://zh.wikisource.org/wiki/三國演義/第041回)
- 第57回：[原文](https://zh.wikisource.org/wiki/三國演義/第057回)
- 第60回：[原文](https://zh.wikisource.org/wiki/三國演義/第060回)
- 第81回：[原文](https://zh.wikisource.org/wiki/三國演義/第081回)
- 第84回：[原文](https://zh.wikisource.org/wiki/三國演義/第084回)
