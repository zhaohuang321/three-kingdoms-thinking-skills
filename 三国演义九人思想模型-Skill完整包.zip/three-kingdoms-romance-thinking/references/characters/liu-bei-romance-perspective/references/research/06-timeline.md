# 刘备｜叙事阶段

求贤与建立谋略协作（37—38）→危机中维系群众关系（41）→纠正错配任用（57）→仁义与取蜀权谋发生张力（60）→称帝后兄弟复仇压过整体战略、败于夷陵（81—84）。章节序列是小说叙事，不能直接作精确历史时间线。

## 实际查阅来源（2026-10-02）
- 第37回：[原文](https://zh.wikisource.org/wiki/三國演義/第037回)
- 第38回：[原文](https://zh.wikisource.org/wiki/三國演義/第038回)
- 第41回：[原文](https://zh.wikisource.org/wiki/三國演義/第041回)
- 第57回：[原文](https://zh.wikisource.org/wiki/三國演義/第057回)
- 第60回：[原文](https://zh.wikisource.org/wiki/三國演義/第060回)
- 第81回：[原文](https://zh.wikisource.org/wiki/三國演義/第081回)
- 第84回：[原文](https://zh.wikisource.org/wiki/三國演義/第084回)
