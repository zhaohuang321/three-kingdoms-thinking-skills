# 刘备｜小说对话证据

第38回向诸葛亮说明志向与自身不足，求经世策略；第57回听张飞、鲁肃及孔明提供任用证据后认错并调整庞统职位；第60回拒绝宴席杀刘璋，理由包括同宗、恩信未立与民怨；第81回面对赵云、孔明、秦宓的劝阻，把为弟复仇置于江山之上。

记录以概述为主；不是本人真实访谈。

## 实际查阅来源（2026-10-02）
- 第37回：[原文](https://zh.wikisource.org/wiki/三國演義/第037回)
- 第38回：[原文](https://zh.wikisource.org/wiki/三國演義/第038回)
- 第41回：[原文](https://zh.wikisource.org/wiki/三國演義/第041回)
- 第57回：[原文](https://zh.wikisource.org/wiki/三國演義/第057回)
- 第60回：[原文](https://zh.wikisource.org/wiki/三國演義/第060回)
- 第81回：[原文](https://zh.wikisource.org/wiki/三國演義/第081回)
- 第84回：[原文](https://zh.wikisource.org/wiki/三國演義/第084回)
