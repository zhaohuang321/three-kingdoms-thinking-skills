# 刘备｜外部视角与叙述评价

徐母第37回的仁义评价是人物话语；第38回叙述者用神化语言赞孔明，间接抬高刘备求贤的结果；第57回张飞的实绩报告及鲁肃荐书促成修正；第84回曹丕预测其连营将败，是对手判断。小说的尊刘叙事倾向不能等同历史结论。

小说人物评价、叙述者赞词、分析者判断三个层次分开。未援引影视、百科或史书补证。

## 实际查阅来源（2026-10-02）
- 第37回：[原文](https://zh.wikisource.org/wiki/三國演義/第037回)
- 第38回：[原文](https://zh.wikisource.org/wiki/三國演義/第038回)
- 第41回：[原文](https://zh.wikisource.org/wiki/三國演義/第041回)
- 第57回：[原文](https://zh.wikisource.org/wiki/三國演義/第057回)
- 第60回：[原文](https://zh.wikisource.org/wiki/三國演義/第060回)
- 第81回：[原文](https://zh.wikisource.org/wiki/三國演義/第081回)
- 第84回：[原文](https://zh.wikisource.org/wiki/三國演義/第084回)
