# 刘备｜作品与文本证据

证据对象是120回小说中的刘备，并非历史刘备的思想全集，也非本人著述。第37—38回写反复求贤及谋略短板；第41回写携民撤退；第57回写用庞统的失误和纠正；第60回写入蜀仁义与取地冲突；第81、84回写复仇与败局。

版本口径：维基文库所载120回章节文本；本批并未做版本学校勘。与史料版目录独立。

## 实际查阅来源（2026-10-02）
- 第37回：[原文](https://zh.wikisource.org/wiki/三國演義/第037回)
- 第38回：[原文](https://zh.wikisource.org/wiki/三國演義/第038回)
- 第41回：[原文](https://zh.wikisource.org/wiki/三國演義/第041回)
- 第57回：[原文](https://zh.wikisource.org/wiki/三國演義/第057回)
- 第60回：[原文](https://zh.wikisource.org/wiki/三國演義/第060回)
- 第81回：[原文](https://zh.wikisource.org/wiki/三國演義/第081回)
- 第84回：[原文](https://zh.wikisource.org/wiki/三國演義/第084回)
