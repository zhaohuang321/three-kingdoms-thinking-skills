# 诸葛亮｜叙事阶段

38回建立宏观路线→46回谋取物资→57回识别岗位错配→95回执行失控及危机撤退→96回军法处理、自责和准备再行动。抽样不是穷尽全部北伐。

## 实际查阅来源（2026-10-02）
- 第38回：[原文](https://zh.wikisource.org/wiki/三國演義/第038回)
- 第46回：[原文](https://zh.wikisource.org/wiki/三國演義/第046回)
- 第57回：[原文](https://zh.wikisource.org/wiki/三國演義/第057回)
- 第95回：[原文](https://zh.wikisource.org/wiki/三國演義/第095回)
- 第96回：[原文](https://zh.wikisource.org/wiki/三國演義/第096回)
